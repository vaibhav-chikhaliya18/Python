import nltk

nltk.download('punkt_tab')
# Download the 'punkt' tokenizer if not already downloaded
try:
    nltk.data.find('tokenizers/punkt')
except LookupError:
    nltk.download('punkt')

# Input text
text = "Python is great. It is used in AI."

# Tokenize the text into sentences
sentences = nltk.tokenize.sent_tokenize(text)

# Print the result
print(sentences)  # Output: ['Python is great.', 'It is used in AI.']