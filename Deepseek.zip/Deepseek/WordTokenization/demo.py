import nltk

text1  = "Hii I Am Vaibhav Chikhaliya,I Am Learn By Ai/ml Data science course.But me anythhing on seerver side"

print(text1)

text1.split(' ')
len(text1.split(' '))

nltk.word_tokenize(text1)