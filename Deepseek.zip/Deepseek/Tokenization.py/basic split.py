text = "Hello world! Welcome to the asus."

# The "formula" is the .split() method
tokens = text.split()

print(tokens)


text = "one:two:three:four"
result = text.split(":", 2)
print(result)  


text = "Vaibhav"
result = list(text)  
print(result)  