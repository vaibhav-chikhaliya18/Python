import nltk
nltk.download('punkt')

# Example Text
text = "Hello! NLTK is a powerful library for NLP tasks."

# Sentence Tokenization
sentences = nltk.sent_tokenize(text)
print("Sentences:", sentences)

# Word Tokenization
words = nltk.word_tokenize(text)
print("Words:", words)
