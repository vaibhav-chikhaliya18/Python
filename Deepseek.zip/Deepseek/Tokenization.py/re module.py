import re
text = "apple;;banana;;orange"
result = re.split(";;", text)
print(result)  # Output: ['apple', 'banana', 'orange']