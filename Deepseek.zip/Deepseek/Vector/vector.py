from transformers import AutoModel, AutoTokenizer
import torch

# Use base model (not chat model) for embeddings
model_name = "deepseek-ai/deepseek-llm-7b-base"

tokenizer = AutoTokenizer.from_pretrained(model_name)
model = AutoModel.from_pretrained(model_name)

text = "DeepSeek is a powerful open-source language model."
inputs = tokenizer(text, return_tensors="pt")

with torch.no_grad():
    outputs = model(**inputs)

# Get the last hidden state (token-level embeddings)
token_embeddings = outputs.last_hidden_state

# Get sentence embedding by averaging token embeddings
sentence_embedding = torch.mean(token_embeddings, dim=1)

print("Vector shape:", sentence_embedding.shape)
print("Sentence embedding vector:", sentence_embedding)
