from transformers import AutoTokenizer

text = "DeepSeek is powerful!"

tokenizer = AutoTokenizer.from_pretrained("deepseek-ai/deepseek-llm-7b-chat")
tokens = tokenizer.tokenize(text)
print(tokens)
input_ids = tokenizer.encode(text, return_tensors="pt")
print(input_ids)

