import spacy
from spacy.symbols import ORTH

nlp = spacy.load("en_core_web_sm")
nlp

doc = nlp("Gimme That")
doc

for token in doc :
    print(token.text)

special_case = [{ORTH:"Gim"},{ORTH:"Me"}]
special_case

nlp.tokenizer.add_special_case("Gimee",special_case)

for token in nlp :
    print(token.text)