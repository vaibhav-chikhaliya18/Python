from transformers import AutoTokenizer, AutoModelForCausalLM
import torch

# Load DeepSeek LLM
model_id = "deepseek-ai/DeepSeek-Coder-7B-Instruct-v1.5"  # Updated model ID
tokenizer = AutoTokenizer.from_pretrained(model_id)
model = AutoModelForCausalLM.from_pretrained(model_id)

# Move model to GPU if available
if torch.cuda.is_available():
    model = model.to("cuda")

# Generate output
input_text = "Explain how transformers work in DeepSeek."
inputs = tokenizer(input_text, return_tensors="pt").to(model.device)  # Move inputs to GPU
outputs = model.generate(**inputs, max_new_tokens=100, do_sample=True, temperature=0.7)
print(tokenizer.decode(outputs[0], skip_special_tokens=True))