from gtts import gTTS
import os

text = "hii,i am asus intel"
tts = gTTS(text=text, lang='en')     
tts.save("voice.mp3")

os.system("start voice.mp3")         
