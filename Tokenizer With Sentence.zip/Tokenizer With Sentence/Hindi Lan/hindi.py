from gtts import gTTS
import os

text = "आपका स्वागत है। नमस्ते! आप कैसे हैं?"
tts = gTTS(text=text, lang='hi')     
tts.save("voice.mp3")

os.system("start voice.mp3")         
