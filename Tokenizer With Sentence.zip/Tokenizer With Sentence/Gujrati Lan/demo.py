from gtts import gTTS
import os

# Step 1: English sentence
sentence = "Good morning, how are you?"

# Step 2: Translate manually to Gujarati pronunciation (approximate)
# Replaced old line with new sentence
gujarati_pronunciation = "કેમ છો? મજા માં. સારું છે તમને."

# Step 3: Use gTTS for Gujarati
tts = gTTS(text=gujarati_pronunciation, lang='gu')
tts.save("output.mp3")

# Step 4: Play the audio (Windows)
os.system("start output.mp3")
