from pydub import AudioSegment
import os

# Paths to your audio files
audio_file1 = r"E:\Python Lan\Pydub Tutorial\sound1.mp3"
audio_file2 = r"E:\Python Lan\Pydub Tutorial\sound2.mp3"

# Load audio files
sound1 = AudioSegment.from_file("hello.mp3")
sound2 = AudioSegment.from_file("audio1.mp3")

# Merge (concatenate)
merged = sound1 + sound2   # or use sound1.append(sound2, crossfade=0)

# Output folder and file
output_folder = r"E:\python\temp_audio"
output_file = os.path.join(output_folder, "merged_concat.mp3")

# Create folder if not exists
os.makedirs(output_folder, exist_ok=True)

# Export merged audio
merged.export(output_file, format="mp3")

print(f"✅ Merged audio saved at: {output_file}")
