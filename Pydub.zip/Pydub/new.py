# import os
# from pydub import AudioSegment

# # Set FFmpeg paths
# AudioSegment.converter = r"C:\ffmpeg\bin\ffmpeg.exe"
# AudioSegment.ffprobe = r"C:\ffmpeg\bin\ffprobe.exe"

# # Paths
# audio_file = r"E:\python\sound1.mp3"
# temp_wav = r"E:\python\temp_audio\temp_sound.wav"

# # Load and export audio
# sound = AudioSegment.from_file(audio_file)
# sound.export(temp_wav, format="wav")

# # Play using ffplay (blocking until finished)
# print("Playing audio...")
# os.system(f'"C:\\ffmpeg\\bin\\ffplay.exe" -nodisp -autoexit "{temp_wav}"')
# print("Playback finished!") 


from pydub import AudioSegment
import os

# 1️⃣ Load your audio file
audio_file = r"E:\Pydub\test1_audio.mp3"
sound = AudioSegment.from_file(audio_file)

# 2️⃣ Increase the volume by 5 dB
louder_sound = sound + 5

# 3️⃣ Export to a temporary WAV file
temp_file = r"E:\Python Lan\Pydub Tutorial\temp_sound.wav"
louder_sound.export(temp_file, format="wav")

# 4️⃣ Play using OS commands (Windows)
print("🎵 Playing sound using OS...")
os.system(f'start "" "{temp_file}"')
