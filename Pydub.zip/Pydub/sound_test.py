# from pydub import AudioSegment
# from pydub.playback import play
# import os
# import tempfile

# # Set FFmpeg paths
# AudioSegment.converter = r"C:\ffmpeg\bin\ffmpeg.exe"
# AudioSegment.ffprobe = r"C:\ffmpeg\bin\ffprobe.exe"

# # Use Python default temp folder
# tempfile.tempdir = None  # Let Python handle the temp dir

# # Load the audio file
# audio_file = "sound1.mp3"  # change to your file
# sound = AudioSegment.from_file(audio_file)

# # Play the audio
# print("Playing audio...")
# play(sound)
# print("Playback finished!")

#2

# from playsound import playsound

# audio_file = r"audio1.mp3"  # change to your file
# print("Playing audio...")
# playsound(audio_file)
# print("Playback finished!")

#3

# from pydub import AudioSegment
# import os

# # 1️⃣ Load your audio file
# audio_file = r"E:\Pydub\test1_audio.mp3"
# sound = AudioSegment.from_file(audio_file)

# # 2️⃣ Increase the volume by 5 dB
# louder_sound = sound + 5

# # 3️⃣ Prepare folder and temp file path
# output_folder = r"E:\Python Lan\Pydub Tutorial"
# os.makedirs(output_folder, exist_ok=True)  # ✅ Create folder if not exists

# temp_file = os.path.join(output_folder, "temp_sound.wav")

# # 4️⃣ Export WAV file
# louder_sound.export(temp_file, format="wav")

# # 5️⃣ Play using OS commands (Windows)
# print("🎵 Playing sound using OS...")
# os.system(f'start "" "{temp_file}"')


#4

# from pydub import AudioSegment
# import os

# # 1 Load your audio file
# audio_file = r"E:\Pydub\test2.mp3"

# if not os.path.exists(audio_file):
#     raise FileNotFoundError(f"Audio file not found: {audio_file}")

# sound = AudioSegment.from_file(audio_file)

# # 2️ Get audio properties
# duration_seconds = len(sound) / 1000          # Pydub uses milliseconds
# channels = sound.channels                     # Mono = 1, Stereo = 2
# sample_width = sound.sample_width              # in bytes (2 = 16-bit audio)
# frame_rate = sound.frame_rate                  # Sample rate in Hz
# frame_width = sound.frame_width                # Bytes per frame
# frame_count = sound.frame_count()              # Number of frames

# # 3️ Print properties
# print("🎵 Audio Properties:")
# print(f"• File: {audio_file}")
# print(f"• Duration: {duration_seconds:.2f} seconds")
# print(f"• Channels: {channels}")
# print(f"• Sample Width: {sample_width * 8} bits")
# print(f"• Frame Rate (Sample Rate): {frame_rate} Hz")
# print(f"• Frame Width: {frame_width} bytes")
# print(f"• Frame Count: {frame_count}")


#5

# from pydub import AudioSegment
# import os

# # 1️⃣ Load your audio file
# audio_file = r"E:\Pydub\test1_audio.mp3"

# if not os.path.exists(audio_file):
#     raise FileNotFoundError(f"Audio file not found: {audio_file}")

# sound = AudioSegment.from_file(audio_file)

# # 2️⃣ Modify the audio (optional: e.g., reduce volume by 3 dB)
# modified_sound = sound - 3

# # 3️⃣ Prepare export folder and file
# export_folder = r"E:\Pydub\exported_audio"
# os.makedirs(export_folder, exist_ok=True)  # ✅ Create folder if missing

# export_file = os.path.join(export_folder, "output_sound.mp3")

# # 4️⃣ Export the audio as MP3
# modified_sound.export(export_file, format="mp3")

# print(f"✅ Audio exported successfully to: {export_file}")

#6

from pydub import AudioSegment
from pydub.silence import split_on_silence

audio = AudioSegment.from_file("test2.mp3")

chunks = split_on_silence(
    audio,
    min_silence_len=5000,  # 1 second silence
    silence_thresh=-40     # Silence threshold in dBFS
)

for i, chunk in enumerate(chunks):
    chunk.export(f"speech_chunk_{i}.mp3", format="mp3")
    print(f"Saved chunk {i}")
