import pandas
mydataset={
        'cars':["Bmw","Audi","Kia"],
        'passsing':[3,7,2]
    }

myvar=pandas.DataFrame(mydataset)

print(myvar)