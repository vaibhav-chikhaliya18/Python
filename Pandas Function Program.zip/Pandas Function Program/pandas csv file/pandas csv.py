import pandas as pd
# import numpy as np
import os

file_path = 'student.csv'

if os.path.exists("E:\Python Lan\Pandas Function Program\pandas csv file\student.csv"):
    df = pd.read_csv("E:\Python Lan\Pandas Function Program\pandas csv file\student.csv")
    print(df.to_string())
else:
    print(f"File '{file_path}' not found.")
