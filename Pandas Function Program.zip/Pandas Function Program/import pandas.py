import pandas as pd

mydataset = {
    'cars':["Kia","Bmw","Audi"],
    'passing':["3","5","8"]
}

myvar = pd.DataFrame(mydataset)
print(myvar)