import pandas as pd

data = {
    'Name' : ['Vaibhav','Krishna','Kevin','Pooja'],
    'Age' : ['21','20','23','24'],
    'Hobby' : ['Coding','Travel','Eatting','Cooking']
}

df = pd.DataFrame(data)
print(df)